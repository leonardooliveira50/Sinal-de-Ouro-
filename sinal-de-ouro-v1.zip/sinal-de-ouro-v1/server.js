/* Sinal de Ouro — servidor (Node 20+, sem dependências externas).
   Inicie com:  node server.js
   Configuração por variáveis de ambiente (veja LEIA-ME.md). */
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const SDO = require("./public/core.js");

/* ================= CONFIGURAÇÃO ================= */
const ENV = process.env;
const CFG = {
  porta: +ENV.PORT || 3000,
  urlPublica: (ENV.PUBLIC_URL || "").replace(/\/$/, ""),
  segredo: ENV.APP_SECRET || "",
  adminEmail: (ENV.ADMIN_EMAIL || "").toLowerCase().trim(),
  pagamento: ENV.PAGAMENTO_MODO || "simulado",          // simulado | mercadopago
  mpToken: ENV.MP_ACCESS_TOKEN || "",
  liberarTodos: ENV.LIBERAR_TODOS === "1",               // fase de testes: todos veem os sinais
  dados: ENV.DADOS || "real",                            // real | demo
  anthropicKey: ENV.ANTHROPIC_API_KEY || "",
  roboMaxUSDT: +ENV.ROBO_MAX_USDT || 50,
  roboMaxDia: +ENV.ROBO_MAX_OPERACOES_DIA || 5,
  roboPermitirReal: ENV.ROBO_PERMITIR_REAL === "1",      // por padrão o robô só opera na conta DEMO da OKX
  pastaDados: ENV.DATA_DIR || path.join(__dirname, "data"),
  okxURL: ENV.OKX_URL || "https://www.okx.com"
};
if (!CFG.segredo) {
  console.warn("⚠  APP_SECRET não definido: usando um segredo temporário. Defina APP_SECRET antes de testar com pessoas.");
  CFG.segredo = crypto.randomBytes(32).toString("hex");
}
const CHAVE = crypto.createHash("sha256").update(CFG.segredo).digest();

/* ================= BANCO (arquivo JSON) ================= */
fs.mkdirSync(CFG.pastaDados, { recursive: true });
const ARQ = path.join(CFG.pastaDados, "db.json");
let db = { users: [], sessoes: {}, pagamentos: [], sinais: [], subs: [], avisos: {}, reclamacoes: [], vapid: null };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(ARQ, "utf8"))); } catch (e) { /* primeiro uso */ }
let salvarTimer = null;
function salvar() {
  clearTimeout(salvarTimer);
  salvarTimer = setTimeout(() => {
    const tmp = ARQ + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, ARQ);
  }, 300);
}

/* ================= UTILIDADES ================= */
const agora = () => Date.now();
const id = (n = 16) => crypto.randomBytes(n).toString("hex");
const b64u = b => Buffer.from(b).toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
function cifrar(txt) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", CHAVE, iv);
  const enc = Buffer.concat([c.update(String(txt), "utf8"), c.final()]);
  return [iv, c.getAuthTag(), enc].map(x => x.toString("base64")).join(".");
}
function decifrar(s) {
  const [iv, tag, enc] = s.split(".").map(x => Buffer.from(x, "base64"));
  const d = crypto.createDecipheriv("aes-256-gcm", CHAVE, iv); d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString("utf8");
}
function hashSenha(senha, sal = crypto.randomBytes(16).toString("hex")) {
  return sal + ":" + crypto.scryptSync(senha, sal, 64).toString("hex");
}
function confereSenha(senha, h) {
  const [sal, hex] = h.split(":"); const a = Buffer.from(hex, "hex"), b = crypto.scryptSync(senha, sal, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
async function getJSON(url, opt = {}) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), opt.timeout || 10000);
  try {
    const r = await fetch(url, { ...opt, signal: ctl.signal });
    const txt = await r.text(); let j = null; try { j = JSON.parse(txt); } catch (e) { }
    if (!r.ok) { const err = new Error("HTTP " + r.status + " " + txt.slice(0, 300)); err.status = r.status; err.body = j; throw err; }
    return j;
  } finally { clearTimeout(t); }
}
const log = (...a) => console.log(new Date().toISOString(), ...a);

/* ================= MOTOR DE SINAIS ================= */
const estado = { modo: CFG.dados === "demo" ? "demo" : "real", atualizado: 0, ativos: {}, fng: null, funding: null };
const velasCache = {};
async function velasReais(a, bar) {
  const inst = a.okx || a.s + "-USDT", okxBar = bar === "1h" ? "1H" : bar === "4h" ? "4H" : bar;
  try {
    const j = await getJSON(`https://www.okx.com/api/v5/market/candles?instId=${inst}&bar=${okxBar}&limit=120`);
    if (j.data && j.data.length > 30) return { fonte: "OKX", c: j.data.map(x => ({ t: +x[0], o: +x[1], h: +x[2], l: +x[3], c: +x[4], v: +x[5] })).reverse() };
  } catch (e) { }
  const j = await getJSON(`https://api.binance.com/api/v3/klines?symbol=${a.bn || a.s + "USDT"}&interval=${bar}&limit=120`);
  if (!Array.isArray(j) || j.length < 30) throw new Error("sem dados");
  return { fonte: "Binance", c: j.map(x => ({ t: x[0], o: +x[1], h: +x[2], l: +x[3], c: +x[4], v: +x[5] })) };
}
async function velas(a, bar) {
  const k = a.s + bar, c = velasCache[k];
  if (c && agora() - c.t < 55000) return c.d;
  const d = estado.modo === "demo" ? SDO.velasDemo(a, bar) : await velasReais(a, bar);
  velasCache[k] = { t: agora(), d }; return d;
}
let rodando = false;
async function ciclo() {
  if (rodando) return; rodando = true;
  try {
    const res = await Promise.allSettled(SDO.ATIVOS.map(a => velas(a, "15m")));
    const novos = [], fechados = [];
    res.forEach((r, i) => {
      const a = SDO.ATIVOS[i];
      if (r.status !== "fulfilled") { log("sem dados", a.s, r.reason && r.reason.message); return; }
      const d = r.value, c = d.c, an = SDO.analisar(c), preco = c[c.length - 1].c;
      estado.ativos[a.s] = { preco, var24: SDO.var24(c), an, fonte: d.fonte, t: c[c.length - 1].t };
      fechados.push(...SDO.conferir(db.sinais, a.s, c));
      const aberto = db.sinais.some(x => x.s === a.s && x.st === "aberto");
      if (!aberto && an.sinal !== "neutro") {
        const t = SDO.alvos(a, preco, an.sinal);
        const s = { id: id(8), s: a.s, dir: an.sinal, entrada: preco, alvo: t.alvo, stop: t.stop, t: c[c.length - 1].t, st: "aberto" };
        db.sinais.unshift(s); novos.push(s);
      }
    });
    db.sinais = db.sinais.slice(0, 2000);
    if (estado.modo === "demo") { estado.fng = { value: "54", value_classification: "Neutral" }; estado.funding = 0.0001; }
    else {
      try { const f = await getJSON("https://api.alternative.me/fng/?limit=1"); estado.fng = f.data[0]; } catch (e) { }
      try { const f = await getJSON("https://www.okx.com/api/v5/public/funding-rate?instId=BTC-USDT-SWAP"); estado.funding = +f.data[0].fundingRate; } catch (e) { }
    }
    estado.atualizado = agora();
    if (novos.length || fechados.length) salvar();
    for (const s of novos) {
      const a = SDO.ATIVOS.find(x => x.s === s.s);
      avisar(s.s, `Novo sinal ${s.s} ${s.dir === "alta" ? "▲ ALTA" : "▼ BAIXA"} · entrada ${num(s.entrada)} · alvo ${num(s.alvo)} · stop ${num(s.stop)}`);
      roboExecutar(a, s).catch(e => log("robô", e.message));
    }
    for (const s of fechados) avisar(s.s, `${s.s}: ${s.st === "alvo" ? "alvo atingido ✓" : "stop acionado"} (${(s.res * 100).toFixed(2)}%)`);
  } catch (e) { log("ciclo", e.message); }
  rodando = false;
}
const num = v => { const a = Math.abs(v); return v.toFixed(a >= 1000 ? 2 : a >= 1 ? 4 : a >= 0.01 ? 5 : 7); };

/* ================= PUSH (alertas com o app fechado) ================= */
if (!db.vapid) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  db.vapid = {
    priv: privateKey.export({ format: "pem", type: "pkcs8" }),
    pub: b64u(publicKey.export({ format: "der", type: "spki" }).subarray(-65))
  };
  salvar();
}
function vapidJWT(endpoint) {
  const aud = new URL(endpoint).origin;
  const h = b64u(JSON.stringify({ typ: "JWT", alg: "ES256" }));
  const p = b64u(JSON.stringify({ aud, exp: Math.floor(agora() / 1000) + 12 * 3600, sub: "mailto:" + (CFG.adminEmail || "contato@sinaldeouro.app") }));
  const sig = crypto.sign("sha256", Buffer.from(h + "." + p), { key: db.vapid.priv, dsaEncoding: "ieee-p1363" });
  return h + "." + p + "." + b64u(sig);
}
async function enviarPush(sub) {
  try {
    const r = await fetch(sub.endpoint, { method: "POST", headers: { TTL: "3600", Urgency: "high", Authorization: `vapid t=${vapidJWT(sub.endpoint)}, k=${db.vapid.pub}`, "Content-Length": "0" } });
    if (r.status === 404 || r.status === 410) { db.subs = db.subs.filter(x => x.endpoint !== sub.endpoint); salvar(); }
  } catch (e) { log("push", e.message); }
}
function avisar(simbolo, texto) {
  for (const u of db.users) {
    const p = u.prefs || {};
    if (!p.alertas || !(p.sinos || []).includes(simbolo) || !acesso(u)) continue;
    for (const sub of db.subs.filter(x => x.uid === u.id)) {
      const fila = (db.avisos[sub.endpoint] = db.avisos[sub.endpoint] || []);
      fila.push({ t: agora(), texto }); db.avisos[sub.endpoint] = fila.slice(-20);
      enviarPush(sub);
    }
  }
  salvar();
}

/* ================= CONTAS ================= */
const pub = u => ({
  id: u.id, nome: u.nome, email: u.email, pago: !!u.pago, acesso: acesso(u), numeroSorte: u.numeroSorte ?? null,
  admin: !!CFG.adminEmail && u.email === CFG.adminEmail, prefs: u.prefs || {},
  robo: u.robo ? { conectado: !!u.robo.k, demo: u.robo.demo !== false, ativo: !!u.robo.ativo, valor: u.robo.valor, moedas: u.robo.moedas || [], log: (u.robo.log || []).slice(0, 20) } : null
});
const acesso = u => CFG.liberarTodos || !!u.pago || (!!CFG.adminEmail && u.email === CFG.adminEmail);
function usuarioDe(req) {
  const t = (req.headers.authorization || "").replace(/^Bearer /, "");
  const s = t && db.sessoes[t];
  if (!s || s.exp < agora()) return null;
  return db.users.find(u => u.id === s.uid) || null;
}
const tentativas = {};
function limitar(ip) {
  const k = ip, t = (tentativas[k] = (tentativas[k] || []).filter(x => agora() - x < 15 * 60000));
  if (t.length >= 10) return false; t.push(agora()); return true;
}
function novaSessao(u) { const t = id(32); db.sessoes[t] = { uid: u.id, exp: agora() + 30 * 864e5 }; salvar(); return t; }

/* ================= PAGAMENTO PIX ================= */
function aprovar(p, origem) {
  if (p.status === "aprovado") return;
  p.status = "aprovado"; p.aprovadoEm = agora(); p.origem = origem;
  const u = db.users.find(x => x.id === p.uid); if (!u) return;
  u.pago = true;
  if (u.numeroSorte == null) {
    const ordem = db.users.filter(x => x.numeroSorte != null).length + 1; // 1ª compra = 001 ... 1000ª = 000
    if (ordem <= 1000) { u.numeroSorte = String(ordem % 1000).padStart(3, "0"); u.ordemCompra = ordem; }
  }
  log("pagamento aprovado", u.email, p.id, origem);
  salvar();
}
async function criarPix(u) {
  const p = { id: id(10), uid: u.id, valor: SDO.PRECO, status: "pendente", criado: agora(), modo: CFG.pagamento };
  if (CFG.pagamento === "mercadopago") {
    if (!CFG.mpToken) throw new Error("MP_ACCESS_TOKEN não configurado");
    const body = {
      transaction_amount: SDO.PRECO, description: "Sinal de Ouro - liberação definitiva", payment_method_id: "pix",
      external_reference: p.id, payer: { email: u.email, first_name: u.nome.split(" ")[0] },
      date_of_expiration: new Date(agora() + 30 * 60000).toISOString().replace("Z", "-00:00")
    };
    if (CFG.urlPublica) body.notification_url = CFG.urlPublica + "/api/pix/webhook";
    const j = await getJSON("https://api.mercadopago.com/v1/payments", {
      method: "POST", body: JSON.stringify(body),
      headers: { Authorization: "Bearer " + CFG.mpToken, "Content-Type": "application/json", "X-Idempotency-Key": p.id }
    });
    const td = (j.point_of_interaction || {}).transaction_data || {};
    p.mpId = j.id; p.qr = td.qr_code; p.qrImg = td.qr_code_base64;
  } else {
    p.qr = "PIX-SIMULADO-" + p.id.toUpperCase();
  }
  db.pagamentos.push(p); salvar(); return p;
}
async function conferirMP(p) {
  if (p.modo !== "mercadopago" || !p.mpId || p.status === "aprovado") return;
  const j = await getJSON("https://api.mercadopago.com/v1/payments/" + p.mpId, { headers: { Authorization: "Bearer " + CFG.mpToken } });
  if (j.status === "approved" && +j.transaction_amount >= SDO.PRECO) aprovar(p, "mercadopago");
  else if (["rejected", "cancelled", "refunded", "charged_back"].includes(j.status)) { p.status = j.status; salvar(); }
}

/* ================= ROBÔ OKX ================= */
async function okx(robo, metodo, caminho, corpo) {
  const ts = new Date().toISOString(), body = corpo ? JSON.stringify(corpo) : "";
  const k = JSON.parse(decifrar(robo.k));
  const sign = crypto.createHmac("sha256", k.secret).update(ts + metodo + caminho + body).digest("base64");
  const headers = { "OK-ACCESS-KEY": k.key, "OK-ACCESS-SIGN": sign, "OK-ACCESS-TIMESTAMP": ts, "OK-ACCESS-PASSPHRASE": k.pass, "Content-Type": "application/json" };
  if (robo.demo !== false) headers["x-simulated-trading"] = "1";
  const j = await getJSON(CFG.okxURL + caminho, { method: metodo, headers, body: body || undefined });
  if (j.code !== "0") throw new Error("OKX " + j.code + ": " + (j.msg || (j.data && j.data[0] && j.data[0].sMsg) || "erro"));
  return j.data;
}
const instCache = {};
async function tick(inst) {
  if (instCache[inst]) return instCache[inst];
  const j = await getJSON(CFG.okxURL + "/api/v5/public/instruments?instType=SPOT&instId=" + inst);
  return (instCache[inst] = +j.data[0].tickSz);
}
const arred = (v, t) => { const d = Math.max(0, -Math.floor(Math.log10(t))); return (Math.round(v / t) * t).toFixed(d); };
async function roboExecutar(a, s) {
  if (s.dir !== "alta") return; // conta à vista (spot) só compra; sinais de baixa ficam só como aviso
  const inst = a.okx || a.s + "-USDT";
  for (const u of db.users) {
    const r = u.robo;
    if (!r || !r.k || !r.ativo || !acesso(u)) continue;
    if (r.moedas && r.moedas.length && !r.moedas.includes(a.s)) continue;
    const hoje = new Date().toDateString();
    const nHoje = (r.log || []).filter(x => x.ok && new Date(x.t).toDateString() === hoje).length;
    const reg = { t: agora(), s: a.s, valor: r.valor };
    if (nHoje >= CFG.roboMaxDia) { reg.ok = false; reg.msg = "Limite diário de operações atingido"; }
    else try {
      const tk = await tick(inst);
      const d = await okx(r, "POST", "/api/v5/trade/order", {
        instId: inst, tdMode: "cash", side: "buy", ordType: "market", sz: String(Math.min(r.valor, CFG.roboMaxUSDT)), tgtCcy: "quote_ccy",
        attachAlgoOrds: [{ tpTriggerPx: arred(s.alvo, tk), tpOrdPx: "-1", slTriggerPx: arred(s.stop, tk), slOrdPx: "-1" }]
      });
      reg.ok = true; reg.ordem = d[0].ordId; reg.msg = `Compra de ${Math.min(r.valor, CFG.roboMaxUSDT)} USDT com alvo ${arred(s.alvo, tk)} e stop ${arred(s.stop, tk)}`;
    } catch (e) { reg.ok = false; reg.msg = e.message.slice(0, 200); }
    r.log = [reg, ...(r.log || [])].slice(0, 100);
    log("robô", u.email, a.s, reg.ok, reg.msg);
  }
  salvar();
}

/* ================= IA DE AJUDA ================= */
const PROMPTS = {
  instalar: "Você é a assistente de instalação do app Sinal de Ouro (um app web instalável). Ajude passo a passo a instalar no Android (Chrome: menu ⋮ > Instalar app) ou iPhone (Safari: Compartilhar > Adicionar à Tela de Início), a ligar alertas e a criar conta. Respostas curtas, em português do Brasil, um passo por vez.",
  duvidas: "Você é o suporte 24h do app Sinal de Ouro. O app mostra sinais automáticos de alta e baixa para ouro (XAUT) e 17 criptomoedas, com alvo e stop por grupo (ouro: alvo 5% e stop 2,5%; grandes BTC/ETH: stop 8%; médias SOL/ADA/XRP/HNT: stop 12%; especulativas: stop 15%; alvo de cripto +29% na alta e −18% na baixa). Os sinais usam médias móveis 9/21, RSI 14 e volume em velas de 15 minutos. A liberação custa R$ 49,90 via Pix, pagamento único. O robô opera na OKX com chave API só de negociação, nunca de saque. Nunca prometa lucro, nunca dê recomendação de investimento personalizada, sempre lembre do stop e de usar valor pequeno. Respostas curtas em português do Brasil.",
  problemas: "Você registra problemas e reclamações de clientes do app Sinal de Ouro. Seja acolhedor, peça os detalhes que faltam (o que aconteceu, quando, em qual tela, celular Android ou iPhone) e diga que a equipe vai responder pelo e-mail cadastrado. Não prometa reembolso nem prazos. Respostas curtas em português do Brasil."
};
async function ajuda(tipo, msgs) {
  if (!CFG.anthropicKey) return null;
  const j = await getJSON("https://api.anthropic.com/v1/messages", {
    method: "POST", timeout: 30000,
    headers: { "x-api-key": CFG.anthropicKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: ENV.ANTHROPIC_MODEL || "claude-haiku-5-5", max_tokens: 500, system: PROMPTS[tipo] || PROMPTS.duvidas, messages: msgs })
  });
  return (j.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
}

/* ================= HTTP ================= */
const TIPOS = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css", ".png": "image/png", ".webmanifest": "application/manifest+json", ".json": "application/json", ".svg": "image/svg+xml" };
const PUB = path.join(__dirname, "public");
function enviar(res, cod, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(cod, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(b);
}
function lerCorpo(req) {
  return new Promise((ok, erro) => {
    let s = ""; req.on("data", c => { s += c; if (s.length > 1e5) { erro(new Error("grande demais")); req.destroy(); } });
    req.on("end", () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { ok({}); } });
  });
}
function arquivo(req, res, p) {
  let f = path.normalize(path.join(PUB, p === "/" ? "index.html" : decodeURIComponent(p)));
  if (!f.startsWith(PUB) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(PUB, "index.html");
  res.writeHead(200, {
    "Content-Type": TIPOS[path.extname(f)] || "application/octet-stream",
    "Cache-Control": f.endsWith("sw.js") || f.endsWith(".html") ? "no-cache" : "public, max-age=3600",
    "X-Content-Type-Options": "nosniff", "Referrer-Policy": "same-origin"
  });
  fs.createReadStream(f).pipe(res);
}
const rotas = {
  "GET /api/saude": async () => ({ ok: true, modo: estado.modo, pagamento: CFG.pagamento, liberarTodos: CFG.liberarTodos, vapid: db.vapid.pub, ia: !!CFG.anthropicKey, preco: SDO.PRECO }),
  "GET /api/campanha": async () => ({ vendidos: Math.min(1000, db.users.filter(u => u.numeroSorte != null).length) }),
  "GET /api/estado": async (req, u) => {
    const liberado = !!u && acesso(u);
    const ativos = {};
    for (const [s, d] of Object.entries(estado.ativos)) ativos[s] = liberado ? d : { preco: d.preco, var24: d.var24, fonte: d.fonte, an: { sinal: "bloqueado" } };
    return { modo: estado.modo, atualizado: estado.atualizado, ativos, fng: estado.fng, funding: estado.funding, bloqueado: !liberado, sinais: liberado ? db.sinais.slice(0, 200) : [] };
  },
  "GET /api/velas": async (req, u, q) => {
    if (!u || !acesso(u)) throw Object.assign(new Error("Acesso não liberado"), { cod: 403 });
    const a = SDO.ATIVOS.find(x => x.s === q.get("s")); const tf = ["15m", "1h", "4h"].includes(q.get("tf")) ? q.get("tf") : "15m";
    if (!a) throw Object.assign(new Error("Moeda desconhecida"), { cod: 404 });
    return await velas(a, tf);
  },
  "POST /api/cadastro": async (req, u, q, b, ip) => {
    if (!limitar(ip)) throw Object.assign(new Error("Muitas tentativas. Aguarde 15 minutos."), { cod: 429 });
    const nome = String(b.nome || "").trim().slice(0, 80), email = String(b.email || "").trim().toLowerCase(), senha = String(b.senha || "");
    if (nome.length < 2) throw Object.assign(new Error("Informe seu nome"), { cod: 400 });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw Object.assign(new Error("E-mail inválido"), { cod: 400 });
    if (senha.length < 8) throw Object.assign(new Error("A senha precisa ter pelo menos 8 caracteres"), { cod: 400 });
    if (!b.aceite) throw Object.assign(new Error("É preciso aceitar os termos e o aviso de risco"), { cod: 400 });
    if (db.users.some(x => x.email === email)) throw Object.assign(new Error("Este e-mail já tem conta. Entre com sua senha."), { cod: 409 });
    const nu = { id: id(8), nome, email, senha: hashSenha(senha), criado: agora(), pago: false, prefs: { favs: SDO.FAV_PADRAO, sinos: [], alertas: false } };
    db.users.push(nu); const token = novaSessao(nu); return { token, usuario: pub(nu) };
  },
  "POST /api/login": async (req, u, q, b, ip) => {
    if (!limitar(ip)) throw Object.assign(new Error("Muitas tentativas. Aguarde 15 minutos."), { cod: 429 });
    const x = db.users.find(y => y.email === String(b.email || "").trim().toLowerCase());
    if (!x || !confereSenha(String(b.senha || ""), x.senha)) throw Object.assign(new Error("E-mail ou senha incorretos"), { cod: 401 });
    return { token: novaSessao(x), usuario: pub(x) };
  },
  "POST /api/sair": async req => { delete db.sessoes[(req.headers.authorization || "").replace(/^Bearer /, "")]; salvar(); return { ok: true }; },
  "GET /api/eu": async (req, u) => { exigir(u); return pub(u); },
  "PUT /api/prefs": async (req, u, q, b) => {
    exigir(u); const ok = s => SDO.ATIVOS.some(a => a.s === s);
    u.prefs = { favs: (b.favs || []).filter(ok).slice(0, 18), sinos: (b.sinos || []).filter(ok), alertas: !!b.alertas };
    salvar(); return pub(u);
  },
  "POST /api/push/inscrever": async (req, u, q, b) => {
    exigir(u); const s = b.subscription;
    if (!s || !/^https:\/\//.test(s.endpoint || "")) throw Object.assign(new Error("Inscrição inválida"), { cod: 400 });
    db.subs = db.subs.filter(x => x.endpoint !== s.endpoint); db.subs.push({ uid: u.id, endpoint: s.endpoint, t: agora() }); salvar();
    return { ok: true };
  },
  "GET /api/avisos": async (req, u, q) => { const e = q.get("e") || ""; const l = db.avisos[e] || []; db.avisos[e] = []; salvar(); return l; },
  "POST /api/pix/criar": async (req, u) => {
    exigir(u); if (u.pago) return { jaPago: true };
    const p = await criarPix(u); return { id: p.id, qr: p.qr, qrImg: p.qrImg || null, simulado: p.modo === "simulado", valor: p.valor };
  },
  "GET /api/pix/status": async (req, u, q) => {
    exigir(u); const p = db.pagamentos.find(x => x.id === q.get("id") && x.uid === u.id);
    if (!p) throw Object.assign(new Error("Pagamento não encontrado"), { cod: 404 });
    try { await conferirMP(p); } catch (e) { log("mp", e.message); }
    return { status: p.status, usuario: pub(u) };
  },
  "POST /api/pix/simular": async (req, u, q, b) => {
    exigir(u); if (CFG.pagamento !== "simulado") throw Object.assign(new Error("Só existe no modo de teste"), { cod: 403 });
    const p = db.pagamentos.find(x => x.id === b.id && x.uid === u.id);
    if (!p) throw Object.assign(new Error("Pagamento não encontrado"), { cod: 404 });
    aprovar(p, "simulado"); return { status: p.status, usuario: pub(u) };
  },
  "POST /api/pix/webhook": async (req, u, q, b) => {
    const mpId = (b.data && b.data.id) || q.get("data.id") || q.get("id");
    const p = mpId && db.pagamentos.find(x => String(x.mpId) === String(mpId));
    if (p) { try { await conferirMP(p); } catch (e) { log("webhook", e.message); } } // confirma direto no Mercado Pago, não confia no aviso
    return { ok: true };
  },
  "PUT /api/robo": async (req, u, q, b) => {
    exigir(u); if (!acesso(u)) throw Object.assign(new Error("Libere o app para usar o robô"), { cod: 403 });
    const r = u.robo || (u.robo = { demo: true, valor: 10, ativo: false, moedas: (u.prefs && u.prefs.favs) || [] });
    if (b.key && b.secret && b.pass) r.k = cifrar(JSON.stringify({ key: String(b.key).trim(), secret: String(b.secret).trim(), pass: String(b.pass) }));
    if (b.demo !== undefined) { if (b.demo === false && !CFG.roboPermitirReal) throw Object.assign(new Error("Conta real bloqueada na fase de testes. Use a conta demo da OKX."), { cod: 403 }); r.demo = b.demo !== false; }
    if (b.valor !== undefined) r.valor = Math.max(1, Math.min(CFG.roboMaxUSDT, +b.valor || 10));
    if (Array.isArray(b.moedas)) r.moedas = b.moedas.filter(s => SDO.ATIVOS.some(a => a.s === s));
    if (b.ativo !== undefined) { if (b.ativo && !r.k) throw Object.assign(new Error("Conecte a chave API primeiro"), { cod: 400 }); r.ativo = !!b.ativo; }
    if (b.remover) { delete r.k; r.ativo = false; }
    salvar(); return pub(u);
  },
  "POST /api/robo/testar": async (req, u) => {
    exigir(u); const r = u.robo; if (!r || !r.k) throw Object.assign(new Error("Conecte a chave API primeiro"), { cod: 400 });
    const conf = await okx(r, "GET", "/api/v5/account/config");
    const perm = String((conf[0] || {}).perm || "");
    if (/withdraw/.test(perm)) { delete r.k; r.ativo = false; salvar(); throw Object.assign(new Error("Esta chave tem permissão de SAQUE. Por segurança ela foi apagada. Crie outra chave só com Ler e Negociar."), { cod: 400 }); }
    const bal = await okx(r, "GET", "/api/v5/account/balance?ccy=USDT");
    const usdt = ((bal[0] || {}).details || []).find(d => d.ccy === "USDT");
    return { ok: true, permissoes: perm, saldoUSDT: usdt ? +usdt.availBal : 0, demo: r.demo !== false };
  },
  "POST /api/ajuda": async (req, u, q, b) => {
    const tipo = ["instalar", "duvidas", "problemas"].includes(b.tipo) ? b.tipo : "duvidas";
    const msgs = (Array.isArray(b.mensagens) ? b.mensagens : []).slice(-12).map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content || "").slice(0, 2000) })).filter(m => m.content);
    if (!msgs.length || msgs[msgs.length - 1].role !== "user") throw Object.assign(new Error("Mensagem vazia"), { cod: 400 });
    if (tipo === "problemas") { db.reclamacoes.unshift({ t: agora(), email: u ? u.email : null, texto: msgs[msgs.length - 1].content }); db.reclamacoes = db.reclamacoes.slice(0, 500); salvar(); }
    let resposta = null; try { resposta = await ajuda(tipo, msgs); } catch (e) { log("ia", e.message); }
    return { resposta, ia: !!resposta };
  },
  "GET /api/admin/resumo": async (req, u) => {
    exigirAdmin(u);
    const fech = db.sinais.filter(x => x.st !== "aberto"), ac = fech.filter(x => x.st === "alvo").length;
    return {
      usuarios: db.users.length, pagos: db.users.filter(x => x.pago).length, receita: db.pagamentos.filter(p => p.status === "aprovado" && p.origem === "mercadopago").length * SDO.PRECO, simulados: db.pagamentos.filter(p => p.status === "aprovado" && p.origem === "simulado").length,
      pagamentosPendentes: db.pagamentos.filter(p => p.status === "pendente").length, sinais: db.sinais.length, acertos: ac, erros: fech.length - ac,
      robosAtivos: db.users.filter(x => x.robo && x.robo.ativo).length, alertasInscritos: db.subs.length, modo: estado.modo, pagamento: CFG.pagamento, liberarTodos: CFG.liberarTodos,
      ultimos: db.users.slice(-30).reverse().map(x => ({ nome: x.nome, email: x.email, pago: !!x.pago, numero: x.numeroSorte ?? null, criado: x.criado })),
      reclamacoes: db.reclamacoes.slice(0, 30)
    };
  },
  "POST /api/admin/liberar": async (req, u, q, b) => {
    exigirAdmin(u); const x = db.users.find(y => y.email === String(b.email || "").toLowerCase().trim());
    if (!x) throw Object.assign(new Error("Usuário não encontrado"), { cod: 404 });
    if (b.liberar === false) { x.pago = false; } else { const p = { id: id(10), uid: x.id, valor: 0, status: "pendente", criado: agora(), modo: "admin" }; db.pagamentos.push(p); aprovar(p, "admin"); }
    salvar(); return { ok: true, usuario: pub(x) };
  },
  "GET /api/admin/sorteio": async (req, u) => {
    exigirAdmin(u);
    return db.users.filter(x => x.numeroSorte != null).sort((a, b) => a.ordemCompra - b.ordemCompra).map(x => ({ numero: x.numeroSorte, ordem: x.ordemCompra, nome: x.nome, email: x.email }));
  }
};
function exigir(u) { if (!u) throw Object.assign(new Error("Entre na sua conta"), { cod: 401 }); }
function exigirAdmin(u) { exigir(u); if (!CFG.adminEmail || u.email !== CFG.adminEmail) throw Object.assign(new Error("Só para administrador"), { cod: 403 }); }

const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x"), chave = req.method + " " + url.pathname;
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
  if (!url.pathname.startsWith("/api/")) return arquivo(req, res, url.pathname);
  const fn = rotas[chave];
  if (!fn) return enviar(res, 404, { erro: "Rota não encontrada" });
  try {
    const corpo = req.method === "GET" ? {} : await lerCorpo(req);
    enviar(res, 200, await fn(req, usuarioDe(req), url.searchParams, corpo, ip));
  } catch (e) {
    const cod = e.cod || 500; if (cod === 500) log("erro", chave, e.message);
    enviar(res, cod, { erro: cod === 500 ? "Erro: " + e.message.slice(0, 200) : e.message });
  }
});
servidor.listen(CFG.porta, () => {
  log(`Sinal de Ouro rodando na porta ${CFG.porta} · dados: ${estado.modo} · pagamento: ${CFG.pagamento} · liberar todos: ${CFG.liberarTodos ? "sim" : "não"} · admin: ${CFG.adminEmail || "(defina ADMIN_EMAIL)"}`);
  ciclo(); setInterval(ciclo, 60000);
});
