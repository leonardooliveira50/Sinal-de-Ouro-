// Sinal de Ouro — service worker: guarda as telas e mostra os alertas com o app fechado.
const CACHE = "sdo-v2";
const SHELL = ["./", "./index.html", "./core.js", "./app.js", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {})); self.skipWaiting(); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n !== CACHE).map(n => caches.delete(n)))));
  self.clients.claim();
});
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (u.origin !== location.origin || u.pathname.includes("/api/") || e.request.method !== "GET") return;
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(CACHE).then(x => x.put(e.request, c)); return r; })
    .catch(() => caches.match(e.request)));
});
// O servidor só "cutuca" o celular; o texto do alerta é buscado aqui.
self.addEventListener("push", e => {
  e.waitUntil((async () => {
    let lista = [];
    try {
      const sub = await self.registration.pushManager.getSubscription();
      const r = await fetch("api/avisos?e=" + encodeURIComponent(sub ? sub.endpoint : ""));
      lista = await r.json();
    } catch (err) { }
    if (!lista.length) lista = [{ texto: "Há novidades nos seus sinais." }];
    for (const a of lista.slice(-3)) await self.registration.showNotification("Sinal de Ouro", { body: a.texto, icon: "icon-192.png", badge: "icon-192.png", tag: "sdo-" + (a.t || Date.now()) });
  })());
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: "window" }).then(l => l.length ? l[0].focus() : clients.openWindow("./")));
});
