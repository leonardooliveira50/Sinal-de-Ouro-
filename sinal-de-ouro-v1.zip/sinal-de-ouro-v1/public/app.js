/* Sinal de Ouro — app (navegador). Usa o servidor quando existe; sem servidor, calcula sozinho (direto) ou simula (demo). */
{
const { GRUPOS, ATIVOS, FAV_PADRAO, PRECO } = SDO;

/* ====== ESTADO ====== */
const ls = { get(k, d) { try { const v = localStorage.getItem("sdo_" + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem("sdo_" + k, JSON.stringify(v)); } catch (e) { } } };
let modo = null;            // servidor | direto | demo
let saude = null, token = ls.get("token", null), eu = null;
let favs = ls.get("favs", FAV_PADRAO), sinos = ls.get("sinos", []), alertasOn = ls.get("alertas", false);
let tema = ls.get("tema", "auto"), filtro = "todas", dados = {}, aberto = null, tf = "15m";
let fng = null, funding = null, sinaisSrv = [], bloqueado = false, pixAtual = null, pixTimer = null;
let ajudaTipo = "duvidas", conversas = { instalar: [], duvidas: [], problemas: [] };

/* ====== UTIL ====== */
const $ = id => document.getElementById(id);
const fmt = v => { if (v == null || !isFinite(v)) return "—"; const a = Math.abs(v); const d = a >= 1000 ? 2 : a >= 1 ? 4 : a >= .01 ? 5 : 7;
  return v.toLocaleString("pt-BR", { minimumFractionDigits: a >= 1000 ? 2 : Math.min(d, 4), maximumFractionDigits: d }); };
const pct = (v, s = true) => v == null || !isFinite(v) ? "—" : (s && v > 0 ? "+" : "") + (v * 100).toLocaleString("pt-BR", { maximumFractionDigits: 2 }) + "%";
const brl = v => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const toast = t => { const e = $("toast"); e.textContent = t; e.classList.add("on"); clearTimeout(toast.h); toast.h = setTimeout(() => e.classList.remove("on"), 3500); };
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
async function getJSON(u, opt = {}) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), opt.timeout || 9000);
  try { const r = await fetch(u, { ...opt, signal: ctl.signal }); const j = await r.json().catch(() => null);
    if (!r.ok) throw Object.assign(new Error((j && j.erro) || "Erro " + r.status), { status: r.status }); return j; }
  finally { clearTimeout(t); }
}
async function api(metodo, rota, corpo) {
  const h = { "Content-Type": "application/json" }; if (token) h.Authorization = "Bearer " + token;
  try { return await getJSON(rota, { method: metodo, headers: h, body: corpo ? JSON.stringify(corpo) : undefined, timeout: 30000 }); }
  catch (e) { if (e.status === 401 && token) { token = null; ls.set("token", null); eu = null; if (modo === "servidor") abrirAuth("login"); } throw e; }
}

/* ====== DADOS: servidor, direto ou demonstração ====== */
async function velasDireto(a, bar) {
  const inst = a.okx || a.s + "-USDT";
  try { const j = await getJSON(`https://www.okx.com/api/v5/market/candles?instId=${inst}&bar=${bar === "1h" ? "1H" : bar === "4h" ? "4H" : bar}&limit=120`);
    if (j.data && j.data.length > 30) return { fonte: "OKX", c: j.data.map(x => ({ t: +x[0], o: +x[1], h: +x[2], l: +x[3], c: +x[4], v: +x[5] })).reverse() }; } catch (e) { }
  const j = await getJSON(`https://api.binance.com/api/v3/klines?symbol=${a.bn || a.s + "USDT"}&interval=${bar}&limit=120`);
  if (!Array.isArray(j) || j.length < 30) throw 0;
  return { fonte: "Binance", c: j.map(x => ({ t: x[0], o: +x[1], h: +x[2], l: +x[3], c: +x[4], v: +x[5] })) };
}
async function detectar() {
  try { const s = await getJSON("api/saude", { timeout: 3000 }); if (s && s.ok) { saude = s; return "servidor"; } } catch (e) { }
  try { await Promise.race([velasDireto(ATIVOS[1], "15m"), new Promise((_, r) => setTimeout(r, 4000))]); return "direto"; } catch (e) { }
  return "demo";
}
async function carregar() {
  $("liveTxt").textContent = "atualizando";
  if (!modo) modo = await detectar();
  if (modo === "servidor") {
    try {
      const e = await api("GET", "api/estado");
      bloqueado = e.bloqueado; sinaisSrv = e.sinais || []; fng = e.fng; funding = e.funding; dados = {};
      for (const [s, d] of Object.entries(e.ativos)) dados[s] = d;
      $("dot").className = "dot " + (e.modo === "demo" ? "demo" : "on");
      $("liveTxt").textContent = (e.modo === "demo" ? "teste · " : "ao vivo · ") + new Date(e.atualizado || Date.now()).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
      const b = $("demoBanner");
      b.hidden = !(e.modo === "demo" || saude.pagamento === "simulado" || saude.liberarTodos);
      b.textContent = "Versão de testes: " + [e.modo === "demo" ? "preços simulados" : null, saude.pagamento === "simulado" ? "Pix simulado (nenhum dinheiro é cobrado)" : null, saude.liberarTodos ? "sinais liberados para todos os testadores" : null].filter(Boolean).join(" · ") + ".";
    } catch (err) { $("liveTxt").textContent = "sem conexão"; }
  } else {
    if (modo === "direto") {
      const res = await Promise.allSettled(ATIVOS.map(a => velasDireto(a, "15m")));
      if (!res.some(r => r.status === "fulfilled")) modo = "demo";
      else { res.forEach((r, i) => { if (r.status === "fulfilled") dados[ATIVOS[i].s] = r.value; });
        try { fng = (await getJSON("https://api.alternative.me/fng/?limit=1")).data[0]; } catch (e) { }
        try { funding = +(await getJSON("https://www.okx.com/api/v5/public/funding-rate?instId=BTC-USDT-SWAP")).data[0].fundingRate; } catch (e) { } }
    }
    if (modo === "demo") { ATIVOS.forEach(a => dados[a.s] = SDO.velasDemo(a, "15m")); fng = { value: "54", value_classification: "Neutral" }; funding = .0001; }
    ATIVOS.forEach(a => { const d = dados[a.s]; if (!d || !d.c) return; d.an = SDO.analisar(d.c); d.preco = d.c[d.c.length - 1].c; d.var24 = SDO.var24(d.c); });
    rastrearLocal();
    $("dot").className = "dot " + (modo === "direto" ? "on" : "demo");
    $("liveTxt").textContent = modo === "direto" ? "ao vivo · " + new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) : "demonstração";
    $("demoBanner").hidden = modo !== "demo";
    $("demoBanner").textContent = "Modo demonstração: os preços são simulados porque esta visualização não pode acessar as corretoras. No servidor do app, os preços são reais.";
  }
  render();
}

/* ====== HISTÓRICO (sem servidor, guardado no aparelho) ====== */
const histKey = () => "hist_" + (modo || "demo");
function rastrearLocal() {
  const h = ls.get(histKey(), []);
  ATIVOS.forEach(a => { const d = dados[a.s]; if (!d || !d.an) return;
    SDO.conferir(h, a.s, d.c).forEach(x => avisoLocal(a, `${a.s}: ${x.st === "alvo" ? "alvo atingido ✓" : "stop acionado"} (${pct(x.res)})`));
    if (!h.some(x => x.s === a.s && x.st === "aberto") && d.an.sinal !== "neutro") { const t = SDO.alvos(a, d.preco, d.an.sinal);
      h.unshift({ id: Date.now() + a.s, s: a.s, dir: d.an.sinal, entrada: d.preco, alvo: t.alvo, stop: t.stop, t: d.c[d.c.length - 1].t, st: "aberto" });
      avisoLocal(a, `Novo sinal ${a.s} ${d.an.sinal === "alta" ? "▲ ALTA" : "▼ BAIXA"} · entrada ${fmt(d.preco)}`); } });
  ls.set(histKey(), h.slice(0, 300));
}
function avisoLocal(a, txt) { if (!alertasOn || !sinos.includes(a.s)) return; toast(txt);
  try { if ("Notification" in window && Notification.permission === "granted") new Notification("Sinal de Ouro", { body: txt, icon: "icon-192.png" }); } catch (e) { } }
const historico = () => modo === "servidor" ? sinaisSrv : ls.get(histKey(), []);

/* ====== RENDER ====== */
const logo = a => `<span class="logo" style="background:${a.c};font-size:${a.s.length > 3 ? 10 : 12}px">${a.s.slice(0, 4)}</span>`;
const tagS = s => s === "alta" ? '<span class="tag up">▲ Alta</span>' : s === "baixa" ? '<span class="tag dn">▼ Baixa</span>' : s === "bloqueado" ? '<span class="tag ne">🔒 Bloqueado</span>' : '<span class="tag ne">Aguardando</span>';
function cartao(a) {
  const d = dados[a.s];
  if (!d || !d.an) return `<div class="coin"><div class="row">${logo(a)}<div><b>${a.s}/USDT</b><div class="small mute">sem dados agora</div></div></div></div>`;
  const s = d.an.sinal, t = SDO.alvos(a, d.preco, s), fav = favs.includes(a.s), g = GRUPOS[a.g];
  return `<div style="position:relative"><button class="coin" data-coin="${a.s}">
  <div class="row">${logo(a)}<div><b style="font-weight:500">${a.s}</b><div class="small mute">${esc(a.n)}</div></div></div>
  <div class="p">${fmt(d.preco)} <span class="small ${d.var24 >= 0 ? "up" : "dn"}">${pct(d.var24)}</span></div>
  <div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap">${tagS(s)}${a.nova ? '<span class="tag new">Nova</span>' : ""}</div>
  ${s === "alta" || s === "baixa" ? `<div class="ts"><span>Alvo<b class="up">${fmt(t.alvo)}</b></span><span>Stop<b class="dn">${fmt(t.stop)}</b></span></div>`
    : `<div class="ts"><span>Alvo<b>+${pct(g.alta, false)}</b></span><span>Stop<b>${pct(g.stop, false)}</b></span></div>`}
 </button><button class="star ${fav ? "on" : ""}" data-fav="${a.s}" aria-label="Favoritar ${a.s}">${fav ? "★" : "☆"}</button></div>`;
}
function render() {
  const vs = ATIVOS.map(a => dados[a.s]).filter(d => d && d.an);
  const med = vs.reduce((s, d) => s + d.var24, 0) / (vs.length || 1);
  $("dayRes").textContent = vs.length ? pct(med) : "—"; $("dayRes").className = "big " + (med >= 0 ? "up" : "dn");
  $("hero").className = "hero " + (med > .001 ? "up" : med < -.001 ? "dn" : "");
  $("dayTxt").textContent = med >= 0 ? "Dia de alta no mercado" : "Dia de baixa no mercado";
  const nA = vs.filter(d => d.an.sinal === "alta").length, nB = vs.filter(d => d.an.sinal === "baixa").length;
  $("nAlta").textContent = bloqueado ? "🔒" : nA; $("nBaixa").textContent = bloqueado ? "🔒" : nB; $("nNeutro").textContent = bloqueado ? "🔒" : vs.length - nA - nB;
  $("semSinal").hidden = bloqueado || nA + nB > 0;
  document.querySelectorAll("[data-lock]").forEach(e => e.hidden = !bloqueado);
  $("fng").textContent = fng ? `${fng.value} · ${({ "Extreme Fear": "medo extremo", Fear: "medo", Neutral: "neutro", Greed: "ganância", "Extreme Greed": "ganância extrema" })[fng.value_classification] || fng.value_classification}` : "—";
  $("funding").textContent = funding == null ? "—" : pct(funding);
  const h = historico(), fech = h.filter(x => x.st !== "aberto"), hoje = new Date().setHours(0, 0, 0, 0);
  const fh = fech.filter(x => x.fim >= hoje), ac = fech.filter(x => x.st === "alvo").length, er = fech.length - ac, soma = fech.reduce((s, x) => s + x.res, 0);
  $("placarHoje").innerHTML = `<span class="up">${fh.filter(x => x.st === "alvo").length}</span> × <span class="dn">${fh.filter(x => x.st === "stop").length}</span>`;
  $("assert").textContent = fech.length ? pct(ac / fech.length, false) : "—";
  $("pnl").textContent = fech.length ? pct(soma) : "—"; $("pnl").className = "v " + (soma >= 0 ? "up" : "dn");
  $("abertos").textContent = h.filter(x => x.st === "aberto").length;
  $("rAc").textContent = ac; $("rEr").textContent = er; $("rAs").textContent = fech.length ? pct(ac / fech.length, false) : "—";
  $("rPnl").textContent = fech.length ? pct(soma) : "—"; $("rPnl").className = "v " + (soma >= 0 ? "up" : "dn");
  $("limpar").hidden = modo === "servidor";
  $("histNota").textContent = modo === "servidor" ? "O placar é o mesmo para todos os clientes e fica registrado no servidor. Cada sinal fecha quando toca o alvo (acerto) ou o stop (erro). Perdas aparecem sempre."
    : "Nesta versão sem servidor, o histórico fica neste aparelho. Cada sinal fecha quando toca o alvo (acerto) ou o stop (erro).";
  $("hist").innerHTML = bloqueado ? '<div class="empty">🔒 O histórico aparece depois da liberação.</div>' : h.length ? h.slice(0, 60).map(x =>
    `<div class="hist"><div><b style="font-weight:500">${x.s}</b> <span class="${x.dir === "alta" ? "up" : "dn"}">${x.dir === "alta" ? "▲" : "▼"}</span>
    <div class="small mute">${new Date(x.t).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })} · entrada ${fmt(x.entrada)}</div></div>
    <div style="text-align:right">${x.st === "aberto" ? '<span class="tag ne">Aberto</span>' : `<span class="${x.res >= 0 ? "up" : "dn"}">${pct(x.res)}</span><div class="small mute">${x.st === "alvo" ? "alvo" : "stop"}</div>`}</div></div>`).join("")
    : '<div class="empty">Nenhum sinal registrado ainda. Os sinais aparecem aqui assim que forem gerados.</div>';
  renderMoedas(); if (aberto) renderDet();
}
function renderMoedas() {
  const F = [["todas", "Todas"], ["fav", "★ Favoritas"], ["alta", "Em alta"], ["novas", "Novas"], ["baixa", "Em baixa"]];
  $("filtros").innerHTML = F.map(([k, l]) => `<button class="chip ${filtro === k ? "on" : ""}" data-f="${k}">${l}</button>`).join("");
  const sig = a => dados[a.s] && dados[a.s].an && dados[a.s].an.sinal;
  const grid = l => l.length ? `<div class="grid2">${l.map(cartao).join("")}</div>` : '<div class="empty">Nenhuma moeda aqui agora.</div>';
  const F1 = ATIVOS.filter(a => favs.includes(a.s)), rest = ATIVOS.filter(a => !favs.includes(a.s));
  let html;
  if (filtro === "todas") html = `<div class="sec">★ Minhas favoritas (${F1.length})</div>${grid(F1)}` + (bloqueado ? `<div class="sec">Outras moedas</div>${grid(rest)}` :
    `<div class="sec">Em alta</div>${grid(rest.filter(a => sig(a) === "alta"))}<div class="sec">Aguardando sinal</div>${grid(rest.filter(a => sig(a) !== "alta" && sig(a) !== "baixa"))}<div class="sec">Em baixa</div>${grid(rest.filter(a => sig(a) === "baixa"))}`);
  else if (filtro === "fav") html = grid(F1);
  else if (filtro === "novas") html = grid(ATIVOS.filter(a => a.nova));
  else html = grid(ATIVOS.filter(a => sig(a) === filtro));
  $("listaMoedas").innerHTML = html;
}
async function velasPara(a, tfx) {
  if (modo === "servidor") return await api("GET", `api/velas?s=${a.s}&tf=${tfx}`);
  if (tfx === "15m" && dados[a.s] && dados[a.s].c) return dados[a.s];
  return modo === "direto" ? await velasDireto(a, tfx) : SDO.velasDemo(a, tfx);
}
async function renderDet() {
  const a = ATIVOS.find(x => x.s === aberto), d = dados[a.s]; if (!d) return;
  if (bloqueado) { $("det").innerHTML = `<div class="row" style="margin-bottom:10px">${logo(a)}<h2 style="font-size:22px;font-weight:400">${a.s}/USDT</h2></div>
    <div class="card"><div class="big">${fmt(d.preco)}</div><div class="small ${d.var24 >= 0 ? "up" : "dn"}">${pct(d.var24)} em 24h</div></div>
    <div class="card lock"><b>🔒 Sinal, alvo, stop e gráfico</b><p class="mute small">Libere o acesso definitivo por R$ 49,90 via Pix.</p><button class="btn" data-go="conta">Liberar acesso</button></div>`; return; }
  const s = d.an.sinal, t = SDO.alvos(a, d.preco, s), g = GRUPOS[a.g], sino = sinos.includes(a.s), ativo = s === "alta" || s === "baixa";
  const lo = Math.min(t.alvo, t.stop), hi = Math.max(t.alvo, t.stop), pos = v => +((v - lo) / (hi - lo) * 100).toFixed(1);
  const em = v => { const q = pos(v); return `left:${q}%;transform:translateX(${q < 12 ? 0 : q > 88 ? -100 : -50}%)`; };
  const rr = s === "baixa" ? g.baixa / g.stop : g.alta / g.stop;
  $("det").innerHTML = `
  <div class="row" style="margin-bottom:10px">${logo(a)}<div><h2 style="font-size:22px;font-weight:400">${a.s}/USDT</h2><div class="small mute">${esc(a.n)} · grupo ${g.nome} · fonte ${esc(d.fonte)}</div></div></div>
  <div class="card"><div class="row"><div class="big">${fmt(d.preco)}</div><span class="sp">${tagS(s)}</span></div>
   <div class="small ${d.var24 >= 0 ? "up" : "dn"}">${pct(d.var24)} em 24h</div>
   <div class="chips" style="margin-top:10px">${["15m", "1h", "4h"].map(x => `<button class="chip ${tf === x ? "on" : ""}" data-tf="${x}">${x === "15m" ? "15 min" : x === "1h" ? "1 hora" : "4 horas"}</button>`).join("")}</div>
   <div class="fig"><svg id="chart"></svg></div></div>
  <div class="card"><h3 style="font-size:17px">${ativo ? "Plano do sinal" : "Sem sinal agora"}</h3>
   ${!ativo ? `<p class="mute small">O mercado desta moeda não mostra direção clara. Quando surgir um sinal, os valores aparecem aqui${sino && alertasOn ? " e você recebe o alerta" : ""}.</p>` : `
   <div class="rule"><i style="left:${pos(t.stop)}%"></i><i style="left:${pos(d.preco)}%;background:var(--gold)"></i><i style="left:${pos(t.alvo)}%"></i>
    <em class="t dn" style="${em(t.stop)}">Stop</em><em class="t gold" style="${em(d.preco)}">Entrada</em><em class="t up" style="${em(t.alvo)}">Alvo</em>
    <em class="b" style="${em(t.stop)}">${fmt(t.stop)}</em><em class="b" style="${em(t.alvo)}">${fmt(t.alvo)}</em></div>
   <div class="kv"><span>Entrada</span><span>${fmt(d.preco)}</span></div>
   <div class="kv"><span>Alvo (${s === "alta" ? "+" + pct(g.alta, false) : "−" + pct(g.baixa, false)})</span><span class="up">${fmt(t.alvo)}</span></div>
   <div class="kv"><span>Stop (${pct(g.stop, false)})</span><span class="dn">${fmt(t.stop)}</span></div>
   <div class="kv"><span>Ganho possível ÷ risco</span><span>${rr.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}×</span></div>`}
  </div>
  <div class="card"><div class="row"><h3 style="font-size:17px">Alerta desta moeda</h3><button class="switch sp ${sino ? "on" : ""}" data-sino="${a.s}" aria-label="Alerta ${a.s}"></button></div>
   <p class="small mute" style="margin:6px 0 0">${alertasOn ? "Alertas gerais ligados." : "Ligue também os alertas gerais na aba Conta."}</p></div>
  <div class="card"><h3 style="font-size:17px">Fontes do sinal</h3>
   <div class="kv"><span>Média rápida × lenta (9 / 21)</span><span class="${d.an.e9 > d.an.e21 ? "up" : "dn"}">${d.an.e9 > d.an.e21 ? "subindo" : "caindo"}</span></div>
   <div class="kv"><span>RSI 14</span><span>${d.an.rsi.toFixed(0)}</span></div>
   <div class="kv"><span>ATR (volatilidade 15 min)</span><span>${pct(d.an.atr / d.preco, false)}</span></div>
   <div class="kv"><span>Volume</span><span>${d.an.vol ? "normal" : "fraco"}</span></div>
   <div class="kv"><span>Fear &amp; Greed</span><span>${fng ? fng.value : "—"}</span></div></div>
  ${a.tese ? `<div class="card"><h3 style="font-size:17px">Sobre a moeda</h3><div class="kv"><span>Tese</span><span>${esc(a.tese)}</span></div><div class="kv"><span>Risco</span><span class="dn">${a.risco}</span></div></div>` : ""}
  ${a.g === "especulativa" ? '<div class="banner">⚠ Moeda de risco alto: use valor pequeno. Em moedas de pouca liquidez o preço pode pular o stop.</div>' : ""}
  <p class="small mute">Não é recomendação de investimento.</p>`;
  let c = d.c; try { c = (await velasPara(a, tf)).c; } catch (e) { }
  if (aberto === a.s && c) desenhar(c, ativo ? t : null, d.preco);
}
function desenhar(c, t, preco) {
  const svg = $("chart"); if (!svg) return;
  const draw = () => { const W = svg.clientWidth, H = svg.clientHeight; if (!W) return;
    const v = c.slice(-80), vals = v.flatMap(x => [x.h, x.l]); let lo = Math.min(...vals), hi = Math.max(...vals);
    const pad = (hi - lo) * .08 || preco * .01; lo -= pad; hi += pad; const y = p => H - 8 - (p - lo) / (hi - lo) * (H - 16), x = i => i / (v.length - 1) * (W - 56);
    const path = v.map((k, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(k.c).toFixed(1)).join("");
    const col = v[v.length - 1].c >= v[0].c ? "var(--up)" : "var(--dn)"; let lines = "";
    if (t) [[t.alvo, "var(--up)", "alvo"], [t.stop, "var(--dn)", "stop"]].forEach(([p, cl, l]) => { if (p > lo && p < hi) lines += `<line x1="0" x2="${W - 56}" y1="${y(p)}" y2="${y(p)}" stroke="${cl}" stroke-dasharray="4 4"/><text x="${W - 52}" y="${y(p) + 4}" font-size="11" fill="${cl}">${l}</text>`; });
    svg.innerHTML = `<path d="${path} L${x(v.length - 1)} ${H} L0 ${H}Z" fill="${col}" opacity=".08"/><path d="${path}" fill="none" stroke="${col}" stroke-width="1.6"/>${lines}
     <line x1="0" x2="${W - 56}" y1="${y(preco)}" y2="${y(preco)}" stroke="var(--gold)" stroke-width=".8"/><text x="${W - 52}" y="${y(preco) + 4}" font-size="11" fill="var(--gold)">agora</text>`; };
  if (desenhar.ro) desenhar.ro.disconnect(); desenhar.ro = new ResizeObserver(draw); desenhar.ro.observe(svg); draw();
}

/* ====== CORRETORAS E ROBÔ ====== */
const CORR = [["OKX", "https://www.okx.com/join", "Robô compatível · conta demo para testes"], ["Binance", "https://www.binance.com/pt-BR/register", "Maior volume do mundo"], ["Bybit", "https://www.bybit.com/pt-BR/register", "Boa para derivativos"]];
function renderRobo() {
  $("corretoras").innerHTML = CORR.map(([n, u, d]) => `<div class="card row"><div><b style="font-weight:500">${n}</b><div class="small mute">${d}</div></div><a class="chip sp" href="${u}" target="_blank" rel="noopener" style="text-decoration:none;color:var(--ink);display:grid;place-items:center">Abrir site</a></div>`).join("")
    + '<p class="small mute" style="margin:-4px 2px 12px">O cadastro e a senha ficam no site da corretora. Ninguém do Sinal de Ouro pede sua senha.</p>';
  const passos = `<div class="sec">Como criar a chave com segurança</div><ol style="padding-left:20px;margin:0">
   <li>Na OKX, ligue a <b>Negociação demo</b> (Trade → Demo trading) para os testes.</li><li>Abra Perfil → API → Criar chave API (dentro do modo demo).</li>
   <li>Marque <b>somente</b> Ler e <b>Negociar (Trade)</b>.</li><li><b class="dn">Nunca</b> marque <b>Saque (Withdraw)</b>. Se marcar, o app apaga a chave.</li><li>Comece com valor pequeno.</li></ol>`;
  if (modo !== "servidor") { $("roboBox").innerHTML = `<div class="card"><div class="row"><h3 style="font-size:17px">Robô OKX</h3><span class="tag ne sp">Precisa do servidor</span></div><p class="mute small">O robô roda no servidor do Sinal de Ouro. Abra o app pelo link do servidor para conectar.</p>${passos}</div>`; return; }
  if (!eu) { $("roboBox").innerHTML = `<div class="card"><h3 style="font-size:17px">Robô OKX</h3><p class="mute small">Entre na sua conta para conectar o robô.</p><button class="btn" id="roboEntrar">Entrar</button></div>`; return; }
  if (!eu.acesso) { $("roboBox").innerHTML = `<div class="card lock"><h3 style="font-size:17px">Robô OKX</h3><p class="mute small">Libere o acesso para usar o robô.</p><button class="btn" data-go="conta">Liberar acesso</button></div>`; return; }
  const r = eu.robo || { conectado: false, demo: true, ativo: false, valor: 10, moedas: favs, log: [] };
  $("roboBox").innerHTML = `<div class="card">
   <div class="row"><h3 style="font-size:17px">Robô OKX</h3><span class="pill ${r.ativo ? "ok" : ""} sp">${r.ativo ? "Ligado" : r.conectado ? "Conectado · desligado" : "Não conectado"}</span></div>
   <div class="banner" style="margin:10px 0">${r.demo ? "Modo DEMO: o robô opera com o dinheiro de teste da OKX. Nenhum dinheiro real é usado." : "Atenção: modo REAL."}</div>
   <p class="small mute">O robô compra quando sai um sinal de <b>alta</b> nas moedas escolhidas, já com o alvo e o stop enviados para a OKX. Sinais de baixa ficam só como aviso, porque a conta à vista não vende a descoberto.</p>
   ${r.conectado ? `<div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn ghost" id="rTestar" style="width:auto">Testar conexão</button><button class="btn ghost" id="rRemover" style="width:auto">Remover chave</button></div><div id="rTeste" class="small" style="margin-top:8px"></div>`
    : `<form id="rForm" style="margin-top:10px"><label class="f">API Key<input id="rKey" autocomplete="off"></label><label class="f">Secret Key<input id="rSec" type="password" autocomplete="off"></label><label class="f">Passphrase<input id="rPass" type="password" autocomplete="off"></label><button class="btn">Conectar chave demo</button></form>`}
   <label class="f" style="margin-top:12px">Valor por operação (USDT)<input id="rValor" type="number" min="1" step="1" value="${r.valor || 10}"></label>
   <div class="sec">Moedas do robô (as favoritas)</div><div class="small">${(r.moedas && r.moedas.length ? r.moedas : favs).join(", ")}</div>
   <div class="row" style="margin-top:14px"><b style="font-weight:400">Ligar robô</b><button class="switch sp ${r.ativo ? "on" : ""}" id="rAtivo" aria-label="Ligar robô"></button></div>
   ${passos}
   ${(r.log || []).length ? `<div class="sec">Últimas operações</div>${r.log.map(l => `<div class="hist"><div><b style="font-weight:500">${l.s}</b><div class="small mute">${new Date(l.t).toLocaleString("pt-BR")} · ${esc(l.msg)}</div></div><span class="pill ${l.ok ? "ok" : "no"}">${l.ok ? "ok" : "falhou"}</span></div>`).join("")}` : ""}
  </div>`;
}
async function salvarRobo(c, msg) { try { eu = await api("PUT", "api/robo", c); if (msg) toast(msg); renderRobo(); } catch (e) { toast(e.message); renderRobo(); } }

/* ====== CONTA, PAGAMENTO E ADMIN ====== */
function renderConta() {
  if (modo !== "servidor") {
    $("contaBox").innerHTML = ""; $("pagBox").innerHTML = `<div class="card"><h3 style="font-size:17px">Liberação definitiva</h3><div class="big gold" style="margin:6px 0">${brl(PRECO)}</div><p class="mute small">Pagamento único por Pix, disponível no app do servidor.</p></div>`;
    $("adminBox").innerHTML = ""; return;
  }
  if (!eu) { $("contaBox").innerHTML = `<div class="card"><h3 style="font-size:17px">Sua conta</h3><p class="mute small">Crie sua conta ou entre para liberar os sinais.</p><button class="btn" id="contaEntrar">Entrar ou criar conta</button></div>`; $("pagBox").innerHTML = ""; $("adminBox").innerHTML = ""; return; }
  $("contaBox").innerHTML = `<div class="card"><div class="row"><div><h3 style="font-size:17px">${esc(eu.nome)}</h3><div class="small mute">${esc(eu.email)}</div></div><button class="chip sp" id="sair">Sair</button></div>
   <div class="row" style="margin-top:10px;gap:8px;flex-wrap:wrap"><span class="pill ${eu.pago ? "ok" : eu.acesso ? "" : "no"}">${eu.pago ? "Acesso liberado" : eu.acesso ? "Liberado para teste" : "Acesso não liberado"}</span>
   ${eu.numeroSorte != null ? `<span class="pill ok">Número da sorte: ${eu.numeroSorte}</span>` : ""}</div></div>`;
  if (eu.pago) $("pagBox").innerHTML = "";
  else if (pixAtual) {
    $("pagBox").innerHTML = `<div class="card"><h3 style="font-size:17px">Pague com Pix</h3><div class="big gold" style="margin:6px 0">${brl(PRECO)}</div>
     ${pixAtual.qrImg ? `<img class="qr" alt="QR Code Pix" src="data:image/png;base64,${pixAtual.qrImg}">` : ""}
     <div class="small mute">Pix copia e cola:</div><div class="code" id="pixCode">${esc(pixAtual.qr)}</div>
     <button class="btn ghost" id="pixCopiar">Copiar código Pix</button>
     <p class="small mute" style="margin:10px 0 0">Aguardando pagamento… A liberação é automática em poucos segundos após o Pix.</p>
     ${pixAtual.simulado ? '<button class="btn" id="pixSimular" style="margin-top:10px">Simular pagamento aprovado (teste)</button>' : ""}</div>`;
  } else $("pagBox").innerHTML = `<div class="card"><h3 style="font-size:17px">Liberação definitiva</h3><div class="big gold" style="margin:6px 0">${brl(PRECO)}</div>
     <p class="mute small" style="margin:0 0 10px">Pagamento único por Pix, com liberação automática. Inclui o app, o robô e todas as atualizações. Os 1.000 primeiros recebem um número da sorte.</p>
     <button class="btn" id="pixGerar">Gerar Pix</button>${saude && saude.pagamento === "simulado" ? '<p class="small mute" style="margin:8px 0 0">Versão de testes: o Pix é simulado e nada é cobrado.</p>' : ""}</div>`;
  if (eu.admin) renderAdmin(); else $("adminBox").innerHTML = "";
}
async function renderAdmin() {
  try {
    const r = await api("GET", "api/admin/resumo");
    $("adminBox").innerHTML = `<div class="card"><h3 style="font-size:17px">Painel do administrador</h3><div class="small mute">${r.modo === "demo" ? "Preços simulados" : "Preços reais"} · Pix ${r.pagamento === "simulado" ? "simulado" : "Mercado Pago"}${r.liberarTodos ? " · sinais liberados para todos" : ""}</div>
     <div class="mini"><div><b>${r.usuarios}</b><span>contas</span></div><div><b>${r.pagos}</b><span>liberadas</span></div><div><b>${brl(r.receita)}</b><span>receita real${r.simulados ? " · " + r.simulados + " Pix simulados" : ""}</span></div>
      <div><b>${r.acertos}×${r.erros}</b><span>placar</span></div><div><b>${r.robosAtivos}</b><span>robôs ligados</span></div><div><b>${r.alertasInscritos}</b><span>celulares c/ alerta</span></div></div>
     <form id="admLib" class="row" style="gap:8px"><input id="admEmail" type="email" placeholder="e-mail do testador"><button class="btn" style="width:auto;padding:0 16px;flex:none">Liberar</button></form>
     <div class="sec">Últimas contas</div>${r.ultimos.map(u => `<div class="hist"><div>${esc(u.nome)}<div class="small mute">${esc(u.email)}</div></div><span class="pill ${u.pago ? "ok" : ""}">${u.pago ? "nº " + (u.numero ?? "—") : "sem pagar"}</span></div>`).join("") || '<div class="empty">Nenhuma conta ainda.</div>'}
     <div class="sec">Reclamações e problemas</div>${r.reclamacoes.map(c => `<div class="hist"><div>${esc(c.texto)}<div class="small mute">${esc(c.email || "sem conta")} · ${new Date(c.t).toLocaleString("pt-BR")}</div></div></div>`).join("") || '<div class="empty">Nenhuma reclamação.</div>'}
     <button class="btn ghost" id="admSorteio" style="margin-top:10px">Copiar lista do sorteio (números da sorte)</button></div>`;
  } catch (e) { $("adminBox").innerHTML = ""; }
}
async function gerarPix() { try { const p = await api("POST", "api/pix/criar"); if (p.jaPago) { await atualizarEu(); return; } pixAtual = p; renderConta(); vigiarPix(); } catch (e) { toast(e.message); } }
function vigiarPix() { clearInterval(pixTimer); let n = 0;
  pixTimer = setInterval(async () => { if (!pixAtual || ++n > 360) return clearInterval(pixTimer);
    try { const r = await api("GET", "api/pix/status?id=" + pixAtual.id); if (r.status === "aprovado") pago(r.usuario); else if (r.status !== "pendente") { clearInterval(pixTimer); pixAtual = null; toast("Pix " + r.status + ". Gere um novo."); renderConta(); } } catch (e) { } }, 5000); }
function pago(u) { clearInterval(pixTimer); pixAtual = null; eu = u; toast("Pagamento aprovado! Acesso liberado" + (u.numeroSorte != null ? " · número da sorte " + u.numeroSorte : "")); renderConta(); renderRobo(); carregar(); campanha(); }
async function atualizarEu() { try { eu = await api("GET", "api/eu"); const p = eu.prefs || {}; if (p.favs && p.favs.length) favs = p.favs; sinos = p.sinos || []; alertasOn = !!p.alertas; $("swAlertas").classList.toggle("on", alertasOn); } catch (e) { eu = null; } renderConta(); renderRobo(); }
function salvarPrefs() { ls.set("favs", favs); ls.set("sinos", sinos); ls.set("alertas", alertasOn); if (modo === "servidor" && eu) api("PUT", "api/prefs", { favs, sinos, alertas: alertasOn }).catch(() => { }); }

/* ====== ALERTAS PUSH ====== */
const b64ToU8 = s => { const p = "=".repeat((4 - s.length % 4) % 4), b = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from([...b].map(c => c.charCodeAt(0))); };
async function inscreverPush() {
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) { $("alertaTxt").textContent = "Este navegador não recebe alertas com o app fechado. No iPhone, instale o app na Tela de Início primeiro (iOS 16.4 ou mais novo)."; return false; }
  const perm = await Notification.requestPermission(); if (perm !== "granted") { toast("Permita as notificações para receber alertas"); return false; }
  const reg = await navigator.serviceWorker.ready;
  let sub = await reg.pushManager.getSubscription();
  if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(saude.vapid) });
  await api("POST", "api/push/inscrever", { subscription: sub.toJSON() }); return true;
}

/* ====== AJUDA COM IA ====== */
const FAQ = [["alvo stop", "O que é alvo e stop?", "Alvo é o preço onde o sinal busca o lucro. Stop é o preço de saída para limitar a perda se o mercado for contra. Use sempre os dois."],
  ["preço preços fonte okx binance", "De onde vêm os preços?", "Das APIs públicas da OKX e, como reserva, da Binance, atualizadas a cada minuto."],
  ["sinal gerado como funciona análise", "Como o sinal é gerado?", "Por análise técnica automática em velas de 15 minutos: médias móveis 9 e 21, RSI e volume. Sem direção clara, não há sinal."],
  ["quanto investir valor", "Quanto devo investir?", "Comece com um valor pequeno que você aceite perder, principalmente nas moedas especulativas."],
  ["garante lucro ganhar", "O app garante lucro?", "Não. Nenhum sinal garante lucro. O placar mostra acertos e erros reais, sem esconder perdas."],
  ["pix pagamento pagar liberar", "Como funciona o pagamento?", "Na aba Conta, toque em Gerar Pix e pague R$ 49,90. A liberação é automática e definitiva."],
  ["robô robo okx api chave", "Como ligo o robô?", "Na aba Robô, crie na OKX uma chave API só com Ler e Negociar (nunca Saque), cole no app e ligue o robô. Comece pela conta demo."],
  ["instalar android iphone tela", "Como instalo no celular?", "Android: no Chrome, menu ⋮ e Instalar app. iPhone: no Safari, Compartilhar e Adicionar à Tela de Início."]];
function respostaLocal(t) { const q = t.toLowerCase(); const f = FAQ.find(([k]) => k.split(" ").some(w => q.includes(w)));
  return ajudaTipo === "problemas" ? "Recebemos sua mensagem. A equipe vai responder pelo e-mail da sua conta. Se puder, diga em qual tela aconteceu e se o celular é Android ou iPhone." : f ? f[2] : "Não encontrei essa resposta. Veja as perguntas frequentes abaixo ou descreva de outro jeito."; }
function renderChat() {
  document.querySelectorAll("#segAjuda button").forEach(b => b.classList.toggle("on", b.dataset.a === ajudaTipo));
  const ini = { instalar: "Oi! Vou te ajudar a instalar o Sinal de Ouro. Seu celular é Android ou iPhone?", duvidas: "Oi! Sou a ajuda 24h do Sinal de Ouro. Qual é a sua dúvida?", problemas: "Conte o que aconteceu. Sua mensagem vai para a equipe." }[ajudaTipo];
  $("chat").innerHTML = `<div class="msg a">${ini}</div>` + conversas[ajudaTipo].map(m => `<div class="msg ${m.role === "user" ? "u" : "a"}">${esc(m.content)}</div>`).join("");
  $("chat").scrollTop = 1e6;
}
async function enviarChat(txt) {
  const c = conversas[ajudaTipo]; c.push({ role: "user", content: txt }); c.push({ role: "assistant", content: "…" }); renderChat();
  let r = null;
  if (modo === "servidor") try { const j = await api("POST", "api/ajuda", { tipo: ajudaTipo, mensagens: c.slice(0, -1) }); r = j.resposta; } catch (e) { }
  c[c.length - 1].content = r || respostaLocal(txt); renderChat();
}

/* ====== AUTENTICAÇÃO ====== */
let authModo = "cadastro";
function abrirAuth(m) { authModo = m || "cadastro"; $("auth").classList.add("on"); $("aErro").textContent = ""; pintarAuth(); }
function pintarAuth() {
  document.querySelectorAll("#segAuth button").forEach(b => b.classList.toggle("on", b.dataset.m === authModo));
  document.querySelectorAll("[data-cad]").forEach(e => e.hidden = authModo !== "cadastro");
  $("aBtn").textContent = authModo === "cadastro" ? "Criar conta" : "Entrar";
  $("aSenha").autocomplete = authModo === "cadastro" ? "new-password" : "current-password";
}

/* ====== NAVEGAÇÃO E EVENTOS ====== */
function ir(v) {
  document.querySelectorAll(".view").forEach(e => e.classList.toggle("on", e.id === "v-" + v));
  document.querySelectorAll("nav.tabs button").forEach(b => b.classList.toggle("on", b.dataset.go === v || (v === "detalhe" && b.dataset.go === "moedas")));
  if (v === "robo") renderRobo(); if (v === "conta") renderConta(); window.scrollTo(0, 0);
}
document.addEventListener("click", async e => {
  const el = s => e.target.closest(s);
  let x;
  if ((x = el("[data-go]"))) return ir(x.dataset.go);
  if ((x = el("[data-fav]"))) { const s = x.dataset.fav; favs = favs.includes(s) ? favs.filter(y => y !== s) : [...favs, s]; salvarPrefs(); renderMoedas(); return toast(favs.includes(s) ? s + " nas favoritas" : s + " saiu das favoritas"); }
  if ((x = el("[data-coin]"))) { aberto = x.dataset.coin; tf = "15m"; ir("detalhe"); return renderDet(); }
  if ((x = el("[data-f]"))) { filtro = x.dataset.f; return renderMoedas(); }
  if ((x = el("[data-tf]"))) { tf = x.dataset.tf; return renderDet(); }
  if ((x = el("[data-sino]"))) { const s = x.dataset.sino; sinos = sinos.includes(s) ? sinos.filter(y => y !== s) : [...sinos, s]; salvarPrefs(); return renderDet(); }
  if ((x = el("[data-a]"))) { ajudaTipo = x.dataset.a; return renderChat(); }
  if ((x = el("[data-m]"))) { authModo = x.dataset.m; return pintarAuth(); }
  const idc = e.target.id;
  if (idc === "contaEntrar" || idc === "roboEntrar") return abrirAuth("login");
  if (idc === "sair") { try { await api("POST", "api/sair"); } catch (er) { } token = null; ls.set("token", null); eu = null; bloqueado = true; renderConta(); renderRobo(); carregar(); return toast("Você saiu da conta"); }
  if (idc === "pixGerar") return gerarPix();
  if (idc === "pixCopiar") { try { await navigator.clipboard.writeText(pixAtual.qr); toast("Código Pix copiado"); } catch (er) { toast("Selecione o código e copie"); } return; }
  if (idc === "pixSimular") { try { const r = await api("POST", "api/pix/simular", { id: pixAtual.id }); pago(r.usuario); } catch (er) { toast(er.message); } return; }
  if (idc === "rTestar") { $("rTeste").textContent = "Testando…"; try { const r = await api("POST", "api/robo/testar"); $("rTeste").innerHTML = `<span class="up">Conexão ok</span> · ${r.demo ? "conta demo" : "conta real"} · saldo ${r.saldoUSDT.toLocaleString("pt-BR")} USDT · permissões: ${esc(r.permissoes)}`; } catch (er) { $("rTeste").innerHTML = `<span class="dn">${esc(er.message)}</span>`; await atualizarEu(); } return; }
  if (idc === "rRemover") return salvarRobo({ remover: true }, "Chave removida");
  if (idc === "rAtivo") { const on = !(eu.robo && eu.robo.ativo); return salvarRobo({ ativo: on, moedas: favs, valor: +$("rValor").value }, on ? "Robô ligado" : "Robô desligado"); }
  if (idc === "admSorteio") { try { const l = await api("GET", "api/admin/sorteio"); await navigator.clipboard.writeText("numero;ordem;nome;email\n" + l.map(u => [u.numero, u.ordem, u.nome, u.email].join(";")).join("\n")); toast(l.length + " números copiados"); } catch (er) { toast(er.message); } return; }
});
document.addEventListener("submit", async e => {
  e.preventDefault(); const f = e.target.id;
  if (f === "authForm") {
    $("aErro").textContent = ""; $("aBtn").disabled = true;
    try {
      const r = authModo === "cadastro" ? await api("POST", "api/cadastro", { nome: $("aNome").value, email: $("aEmail").value, senha: $("aSenha").value, aceite: $("aAceite").checked })
        : await api("POST", "api/login", { email: $("aEmail").value, senha: $("aSenha").value });
      token = r.token; ls.set("token", token); $("auth").classList.remove("on"); $("aSenha").value = "";
      await atualizarEu(); salvarPrefs(); carregar(); toast("Bem-vindo, " + eu.nome.split(" ")[0]);
      if (!eu.acesso) ir("conta");
    } catch (er) { $("aErro").textContent = er.message; }
    $("aBtn").disabled = false;
  }
  if (f === "rForm") return salvarRobo({ key: $("rKey").value, secret: $("rSec").value, pass: $("rPass").value, demo: true, valor: +$("rValor").value, moedas: favs }, "Chave conectada. Toque em Testar conexão.");
  if (f === "admLib") { try { await api("POST", "api/admin/liberar", { email: $("admEmail").value }); toast("Acesso liberado"); renderAdmin(); } catch (er) { toast(er.message); } }
  if (f === "chatForm") { const t = $("chatIn").value.trim(); if (!t) return; $("chatIn").value = ""; enviarChat(t); }
});
document.addEventListener("change", e => { if (e.target.id === "rValor" && eu && eu.robo) salvarRobo({ valor: +e.target.value }, "Valor salvo"); });
$("voltar").onclick = () => ir("moedas");
$("refresh").onclick = () => carregar();
$("limpar").onclick = () => { const b = $("limpar"); if (b.dataset.c) { ls.set(histKey(), []); render(); b.textContent = "Limpar"; delete b.dataset.c; toast("Histórico limpo"); } else { b.dataset.c = 1; b.textContent = "Toque para confirmar"; setTimeout(() => { b.textContent = "Limpar"; delete b.dataset.c; }, 3000); } };
function aplicarTema() { const r = document.documentElement; tema === "auto" ? r.removeAttribute("data-theme") : r.setAttribute("data-theme", tema);
  document.querySelectorAll("#tema button").forEach(b => b.classList.toggle("on", b.dataset.t === tema)); }
$("tema").onclick = e => { const b = e.target.closest("[data-t]"); if (!b) return; tema = b.dataset.t; ls.set("tema", tema); aplicarTema(); };
$("swAlertas").classList.toggle("on", alertasOn);
$("swAlertas").onclick = async () => {
  if (modo === "servidor" && !eu) return abrirAuth("login");
  alertasOn = !alertasOn; $("swAlertas").classList.toggle("on", alertasOn);
  if (alertasOn) {
    if (!sinos.length) sinos = [...favs];
    try { if (modo === "servidor") { if (!(await inscreverPush())) { alertasOn = false; $("swAlertas").classList.remove("on"); } }
      else if ("Notification" in window && Notification.permission === "default") await Notification.requestPermission(); } catch (er) { toast("Não foi possível ligar os alertas neste navegador"); }
    if (alertasOn) toast("Alertas ligados para " + sinos.length + " moedas");
  } else toast("Alertas desligados");
  salvarPrefs();
};
const PASSOS = { android: ["Abra o link do app no Chrome.", "Toque nos três pontinhos ⋮ no canto de cima.", "Escolha “Instalar app” ou “Adicionar à tela inicial”.", "Abra o Sinal de Ouro pelo ícone dourado."],
  iphone: ["Abra o link do app no Safari.", "Toque no botão Compartilhar (quadrado com seta).", "Escolha “Adicionar à Tela de Início”.", "Abra o Sinal de Ouro pelo ícone dourado. Os alertas no iPhone só funcionam assim."] };
function inst(k) { $("passosInst").innerHTML = PASSOS[k].map(p => `<li>${p}</li>`).join(""); document.querySelectorAll("#segInst button").forEach(b => b.classList.toggle("on", b.dataset.i === k)); }
$("segInst").onclick = e => { const b = e.target.closest("[data-i]"); if (b) inst(b.dataset.i); };
$("faq").innerHTML = FAQ.map(([, q, r]) => `<details><summary>${q}</summary><p>${r}</p></details>`).join("");
function capa(on) { $("capa").classList.toggle("on", on); if (!on) ls.set("viuCapa", true); }
async function campanha() { let v = 0; if (modo === "servidor") try { v = (await api("GET", "api/campanha")).vendidos; } catch (e) { }
  $("barCamp").style.width = (v / 10) + "%"; $("txtCamp").textContent = v.toLocaleString("pt-BR") + " de 1.000 vagas preenchidas"; }
$("entrar").onclick = () => { capa(false); if (modo === "servidor" && !eu) abrirAuth("cadastro"); else ir("conta"); };
$("entrar2").onclick = () => { capa(false); if (modo === "servidor" && !eu) abrirAuth("login"); };
$("verCapa").onclick = () => capa(true);
$("authVoltar").onclick = () => $("auth").classList.remove("on");

/* ====== INÍCIO ====== */
(async () => {
  aplicarTema(); inst("android"); renderChat();
  if (!ls.get("viuCapa", false)) capa(true);
  modo = await detectar();
  if (modo === "servidor") { bloqueado = true; if (token) await atualizarEu(); if (!eu && ls.get("viuCapa", false)) abrirAuth("login"); }
  campanha(); renderRobo(); renderConta();
  await carregar(); setInterval(carregar, 60000);
  try { if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) navigator.serviceWorker.register("sw.js").catch(() => { }); } catch (e) { }
})();
}
