/* Sinal de Ouro — núcleo compartilhado entre o app (navegador) e o servidor (Node).
   Mudou uma regra aqui, mudou nos dois lugares. */
(function (root) {
  const GRUPOS = {
    ouro:         { nome: "Ouro",         stop: 0.025, alta: 0.05, baixa: 0.05 },
    grande:       { nome: "Grande",       stop: 0.08,  alta: 0.29, baixa: 0.18 },
    media:        { nome: "Média",        stop: 0.12,  alta: 0.29, baixa: 0.18 },
    especulativa: { nome: "Especulativa", stop: 0.15,  alta: 0.29, baixa: 0.18 }
  };
  const ATIVOS = [
    { s: "XAUT", n: "Ouro (XAUT)", g: "ouro", okx: "XAUT-USDT", bn: "PAXGUSDT", c: "#c9a227", demo: 4000 },
    { s: "BTC", n: "Bitcoin", g: "grande", c: "#f7931a", demo: 95000 },
    { s: "ETH", n: "Ethereum", g: "grande", c: "#627eea", demo: 3200 },
    { s: "SOL", n: "Solana", g: "media", c: "#9945ff", demo: 140 },
    { s: "ADA", n: "Cardano", g: "media", c: "#0033ad", demo: 0.45 },
    { s: "XRP", n: "XRP", g: "media", c: "#23292f", demo: 2.1 },
    { s: "HNT", n: "Helium", g: "media", c: "#474dff", demo: 2.5 },
    { s: "FLUID", n: "Fluid", g: "especulativa", nova: 1, tese: "DeFi: empréstimos e liquidez", risco: "alto", c: "#3b82f6", demo: 5 },
    { s: "REI", n: "REI Network", g: "especulativa", nova: 1, tese: "Rede blockchain própria", risco: "alto", c: "#0ea5a4", demo: 0.02 },
    { s: "ZETA", n: "ZetaChain", g: "especulativa", nova: 1, tese: "Interoperabilidade entre redes", risco: "alto", c: "#10b981", demo: 0.15 },
    { s: "TRAC", n: "OriginTrail", g: "especulativa", nova: 1, tese: "Dados e IA", risco: "alto", c: "#6d28d9", demo: 0.4 },
    { s: "NEAR", n: "NEAR", g: "especulativa", nova: 1, tese: "IA e blockchain", risco: "alto", c: "#111827", demo: 2.2 },
    { s: "ENA", n: "Ethena", g: "especulativa", nova: 1, tese: "Dólar sintético", risco: "alto", c: "#334155", demo: 0.3 },
    { s: "JTO", n: "Jito", g: "especulativa", nova: 1, tese: "Staking na Solana", risco: "alto", c: "#16a34a", demo: 1 },
    { s: "PUMP", n: "Pump.fun", g: "especulativa", nova: 1, tese: "Memes", risco: "muito alto", c: "#22c55e", demo: 0.004 },
    { s: "CELR", n: "Celer", g: "especulativa", nova: 1, tese: "Pontes entre redes", risco: "alto", c: "#7c3aed", demo: 0.006 },
    { s: "GLMR", n: "Moonbeam", g: "especulativa", nova: 1, tese: "Compatível com Ethereum na Polkadot", risco: "alto", c: "#e1147b", demo: 0.03 },
    { s: "TRUMP", n: "Official Trump", g: "especulativa", tese: "Memecoin", risco: "muito alto", c: "#b91c1c", demo: 6 }
  ];
  const FAV_PADRAO = ["FLUID", "REI", "ZETA", "TRAC", "NEAR", "ENA", "JTO", "GLMR", "PUMP", "CELR"];
  const PRECO = 49.90;

  function ema(a, p) { const k = 2 / (p + 1); let e = a[0]; return a.map(v => (e = v * k + e * (1 - k))); }
  function rsi(a, p = 14) {
    let g = 0, l = 0;
    for (let i = 1; i <= p; i++) { const d = a[i] - a[i - 1]; d > 0 ? (g += d) : (l -= d); }
    g /= p; l /= p;
    for (let i = p + 1; i < a.length; i++) {
      const d = a[i] - a[i - 1];
      g = (g * (p - 1) + Math.max(d, 0)) / p; l = (l * (p - 1) + Math.max(-d, 0)) / p;
    }
    return l === 0 ? 100 : 100 - 100 / (1 + g / l);
  }
  function atr(c, p = 14) {
    const t = [];
    for (let i = 1; i < c.length; i++) { const x = c[i], pc = c[i - 1].c; t.push(Math.max(x.h - x.l, Math.abs(x.h - pc), Math.abs(x.l - pc))); }
    const s = t.slice(-p); return s.reduce((a, b) => a + b, 0) / (s.length || 1);
  }
  /* Regra do sinal (velas de 15 min):
     ALTA  = média 9 acima da 21, preço acima da 21, RSI entre 50 e 70, volume ok
     BAIXA = média 9 abaixo da 21, preço abaixo da 21, RSI entre 30 e 50, volume ok
     Fora disso: sem sinal (não força operação). */
  function analisar(c) {
    const cl = c.map(x => x.c), e9 = ema(cl, 9), e21 = ema(cl, 21), r = rsi(cl), n = cl.length - 1;
    const volM = c.slice(-21, -1).reduce((a, x) => a + x.v, 0) / 20, vol = c[n].v >= volM * 0.6;
    let sinal = "neutro";
    if (e9[n] > e21[n] && cl[n] > e21[n] && r > 50 && r < 70 && vol) sinal = "alta";
    else if (e9[n] < e21[n] && cl[n] < e21[n] && r < 50 && r > 30 && vol) sinal = "baixa";
    return { sinal, rsi: r, e9: e9[n], e21: e21[n], atr: atr(c), vol };
  }
  function alvos(a, preco, sinal) {
    const g = GRUPOS[a.g], al = sinal !== "baixa";
    return { alvo: preco * (al ? 1 + g.alta : 1 - g.baixa), stop: preco * (al ? 1 - g.stop : 1 + g.stop) };
  }
  function var24(c) { const n = c.length - 1; return c.length >= 96 ? c[n].c / c[n - 95].o - 1 : c[n].c / c[0].o - 1; }
  /* Velas simuladas, só para demonstração e testes sem internet. */
  function velasDemo(a, bar, agora = Date.now()) {
    const step = { "15m": 9e5, "1h": 36e5, "4h": 144e5 }[bar] || 9e5;
    let seed = [...(a.s + bar)].reduce((x, ch) => (x * 31 + ch.charCodeAt(0)) >>> 0, 7);
    const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
    const vol = a.g === "ouro" ? 0.0015 : a.g === "grande" ? 0.003 : a.g === "media" ? 0.005 : 0.007;
    const now = Math.floor(agora / step) * step; let p = a.demo; const drift = (rnd() - 0.5) * vol * 0.6, out = [];
    for (let i = 119; i >= 0; i--) {
      const o = p; p = o * (1 + drift + (rnd() - 0.5) * vol * 2);
      out.push({ t: now - i * step, o, h: Math.max(o, p) * (1 + rnd() * vol * 0.5), l: Math.min(o, p) * (1 - rnd() * vol * 0.5), c: p, v: 1e3 * (0.5 + rnd()) });
    }
    const L = out[119], j = 1 + Math.sin(agora / 6e4 + a.demo) * vol * 0.4;
    L.c *= j; L.h = Math.max(L.h, L.c); L.l = Math.min(L.l, L.c);
    return { fonte: "Demonstração", c: out };
  }
  /* Fecha sinais abertos que tocaram alvo ou stop; devolve os que fecharam. */
  function conferir(sinais, s, velas) {
    const fechados = [];
    for (const x of sinais) {
      if (x.s !== s || x.st !== "aberto") continue;
      for (const v of velas) {
        if (v.t < x.t) continue;
        const hitA = x.dir === "alta" ? v.h >= x.alvo : v.l <= x.alvo;
        const hitS = x.dir === "alta" ? v.l <= x.stop : v.h >= x.stop;
        if (hitS) { x.st = "stop"; x.fim = v.t; x.res = x.dir === "alta" ? x.stop / x.entrada - 1 : 1 - x.stop / x.entrada; break; }
        if (hitA) { x.st = "alvo"; x.fim = v.t; x.res = x.dir === "alta" ? x.alvo / x.entrada - 1 : 1 - x.alvo / x.entrada; break; }
      }
      if (x.st !== "aberto") fechados.push(x);
    }
    return fechados;
  }
  const SDO = { GRUPOS, ATIVOS, FAV_PADRAO, PRECO, ema, rsi, atr, analisar, alvos, var24, velasDemo, conferir };
  if (typeof module !== "undefined" && module.exports) module.exports = SDO; else root.SDO = SDO;
})(typeof globalThis !== "undefined" ? globalThis : this);
