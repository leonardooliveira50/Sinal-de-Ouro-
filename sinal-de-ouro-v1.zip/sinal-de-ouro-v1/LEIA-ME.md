# Sinal de Ouro — versão de testes 1.0

App de sinais de ouro e 17 criptomoedas, com alvo e stop em cada sinal. Funciona no celular como aplicativo (Android e iPhone), instalado pelo navegador.

**Tudo já funciona:** cadastro e login, Pix com liberação automática, sinais com preços reais, placar único para todos os clientes, alertas no celular mesmo com o app fechado, robô na OKX, ajuda com IA, campanha com número da sorte e painel do administrador.

---

## 1. Colocar no ar para os testes (Render, grátis, cerca de 15 minutos)

O app precisa de um servidor ligado o tempo todo (é ele que acompanha os preços, gera os sinais e liga o robô). Recomendo o **Render**.

1. Crie uma conta no **GitHub** (github.com) e um repositório novo chamado `sinal-de-ouro`.
2. Envie todos os arquivos desta pasta para o repositório (botão *Add file → Upload files*, arraste tudo).
3. Crie uma conta no **Render** (render.com) entrando com o GitHub.
4. Clique em **New → Blueprint**, escolha o repositório `sinal-de-ouro` e confirme. O arquivo `render.yaml` já configura tudo.
5. O Render vai pedir o valor de **ADMIN_EMAIL**: coloque o seu e-mail. Esse e-mail vira o administrador.
6. Em alguns minutos o Render mostra o link do app (ex.: `https://sinal-de-ouro.onrender.com`).
7. No Render, em *Environment*, coloque esse link em **PUBLIC_URL**.
8. Abra o link no celular, crie sua conta com o e-mail de administrador e instale o app na tela inicial.

> **Plano grátis do Render:** o servidor "dorme" depois de 15 minutos sem visitas e perde os dados quando reinicia. Para um teste de verdade, com sinais e placar contínuos, use o plano **Starter (US$ 7/mês) com disco** (já está no `render.yaml` como comentário) ou qualquer servidor VPS.

## 2. Configurações (variáveis de ambiente)

| Variável | O que faz | Valor na fase de testes |
|---|---|---|
| `ADMIN_EMAIL` | E-mail do administrador | seu e-mail |
| `APP_SECRET` | Senha interna que protege as chaves do robô | o Render gera sozinho |
| `PUBLIC_URL` | Link público do app | o link do Render |
| `PAGAMENTO_MODO` | `simulado` (nenhum dinheiro cobrado) ou `mercadopago` | `simulado` |
| `MP_ACCESS_TOKEN` | Token do Mercado Pago (use primeiro o de **teste**) | vazio no começo |
| `LIBERAR_TODOS` | `1` libera os sinais para todos os testadores, sem pagar | `1` ou `0` |
| `DADOS` | `real` (preços da OKX/Binance) ou `demo` (simulados) | `real` |
| `ANTHROPIC_API_KEY` | Liga a IA de ajuda (sem ela, o app responde com as perguntas frequentes) | opcional |
| `ROBO_MAX_USDT` | Valor máximo por operação do robô | `50` |
| `ROBO_MAX_OPERACOES_DIA` | Máximo de operações por dia, por cliente | `5` |
| `ROBO_PERMITIR_REAL` | `1` libera o robô em conta real da OKX | **não definir** nos testes |

## 3. Roteiro de testes (marque cada item)

**Conta e acesso**
- [ ] Criar conta sem marcar o aviso de risco → o app recusa.
- [ ] Criar conta, sair e entrar de novo com a mesma senha.
- [ ] Senha errada → mensagem "E-mail ou senha incorretos".
- [ ] Com `LIBERAR_TODOS=0`, uma conta nova vê os preços mas os sinais aparecem como 🔒.

**Pagamento (modo simulado)**
- [ ] Conta → Gerar Pix → aparece o código Pix.
- [ ] "Simular pagamento aprovado" → acesso liberado na hora e número da sorte (001, 002…).
- [ ] O contador da capa (vagas preenchidas) aumenta.

**Pagamento real em teste (Mercado Pago sandbox)**
- [ ] Criar a conta de desenvolvedor no Mercado Pago e copiar o *Access Token de teste*.
- [ ] `PAGAMENTO_MODO=mercadopago` e `MP_ACCESS_TOKEN=<token de teste>`.
- [ ] Gerar Pix no app → aparece o QR Code do Mercado Pago.
- [ ] Aprovar o pagamento com o usuário de teste do Mercado Pago → o app libera sozinho em até 5 segundos.

**Sinais**
- [ ] Os 18 ativos mostram preço e variação reais (compare com a OKX).
- [ ] Favoritas sempre no topo, estrela liga e desliga.
- [ ] Tocar numa moeda abre o detalhe com gráfico de 15 min, 1 hora e 4 horas, régua stop/entrada/alvo.
- [ ] Conferir o alvo e o stop: cripto +29% / −18% e stop por grupo (8%, 12%, 15%); ouro ±5% e stop 2,5%.
- [ ] Resultados: os sinais fecham como "alvo" ou "stop" e o placar é igual em dois celulares diferentes.

**Alertas**
- [ ] Android: ligar Alertas na Conta e permitir notificações; ligar o sino de uma moeda.
- [ ] iPhone: instalar na Tela de Início (iOS 16.4+), abrir pelo ícone e ligar os alertas.
- [ ] Com o app fechado, chega a notificação do próximo sinal.

**Robô (somente conta DEMO da OKX)**
- [ ] Na OKX, entrar em *Demo trading* e criar a chave API com **Ler + Negociar** (sem Saque).
- [ ] Conectar a chave no app → "Testar conexão" mostra o saldo demo.
- [ ] Criar uma chave **com Saque** → o app recusa e apaga a chave.
- [ ] Ligar o robô → no próximo sinal de alta de uma favorita, aparece a operação na OKX demo com alvo e stop.
- [ ] O limite de operações por dia é respeitado.

**Ajuda e administrador**
- [ ] Chat de Dúvidas, Instalar e Problemas responde.
- [ ] Mensagem enviada em Problemas aparece no painel do administrador.
- [ ] Painel do administrador: contas, liberadas, placar, liberar um testador pelo e-mail, copiar a lista do sorteio.

## 4. Antes de vender (fora do app)

- Autorização da promoção (sorteio) na SPA/Ministério da Fazenda antes de divulgar.
- Conta de empresa (CNPJ) no Mercado Pago, termos de uso e política de privacidade (LGPD).
- Orientação jurídica sobre a oferta de sinais de investimento.
- Trocar para `PAGAMENTO_MODO=mercadopago` com o token de **produção**, `LIBERAR_TODOS=0`, e só então decidir sobre `ROBO_PERMITIR_REAL`.

## 5. Arquivos

- `server.js`: o servidor (contas, Pix, motor de sinais, alertas, robô OKX, IA, administrador). Não precisa instalar nada além do Node 20+.
- `public/core.js`: as regras (ativos, grupos, alvo, stop, cálculo do sinal), usadas pelo app e pelo servidor.
- `public/app.js`, `public/index.html`: o aplicativo.
- `public/sw.js`, `public/manifest.webmanifest`, ícones: instalação e alertas.
- `data/db.json`: criado sozinho, guarda as contas e os sinais (não envie para o GitHub).

Para rodar no computador: `node server.js` e abra `http://localhost:3000`. Para testar sem internet: `DADOS=demo LIBERAR_TODOS=1 node server.js`.

Os sinais são análise técnica automática e não são recomendação de investimento.
